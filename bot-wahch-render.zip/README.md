# بوت وحش - جاهز لـ Render

## كيفاش تطلقو فـ 2 دقايق بلا كارت:

1. سير لـ https://dashboard.render.com/select-repo?type=web
2. ختار هاد الـ Repo
3. Render غادي يقرا render.yaml بوحدو
4. زيد هاد المتغيرات فـ Environment:
   - GROQ_API_KEY = جيبو من groq.com (فابور)
   - UPSTASH_REDIS_REST_URL = من upstash.com (فابور)
   - UPSTASH_REDIS_REST_TOKEN = من upstash.com

5. ورك Deploy!

## فين نجيب المفاتيح الفابور؟

### Groq (العقل):
https://console.groq.com/keys -> Create API Key

### Upstash (الذاكرة):
https://console.upstash.com -> Create Database -> Redis -> انسخ REST URL و TOKEN

## من ورا Deploy:
غادي يعطيك رابط بحال:
https://wahch-bot-xxxx.onrender.com

حلو -> غادي تلقى AstrBot Dashboard!

### باش ما يطفيش:
سير لـ https://uptimerobot.com -> Add Monitor -> HTTP(s) -> دخل الرابط ديال Render -> كل 5 دقايق يفيقو!

صافي، البوت شاعل 24/24 فابور وخا تطفي البيصي!